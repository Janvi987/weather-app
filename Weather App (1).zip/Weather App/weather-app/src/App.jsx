import WeatherApp from './Components/WeatherApp'
import './Components/WeatherApp.css'

const App = () => {
  return (
    <div>
      <WeatherApp />
    </div>
  )
}

export default App
